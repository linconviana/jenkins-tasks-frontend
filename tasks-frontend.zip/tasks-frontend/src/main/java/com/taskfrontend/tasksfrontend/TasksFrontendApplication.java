package com.taskfrontend.tasksfrontend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TasksFrontendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TasksFrontendApplication.class, args);
	}

}
